#!/usr/bin/env python3
"""
JARVIS — Personalized Local AI Assistant
Hindi + English | Voice | Screen Vision | Full PC Control
"""
import sys
sys.path.insert(0, ".")

from jarvis.memory.db import init_db, remember, recall
from jarvis.core.brain import ask
from jarvis.core.speaker import speak
from jarvis.core.tracker import start_tracking, get_system_stats
import re

def extract_and_execute(response: str) -> str:
    """Parse JARVIS brain response for actionable commands."""
    from jarvis.core import executor as ex
    lower = response.lower()
    if "open browser" in lower or "chrome" in lower:
        ex.open_app("google-chrome || xdg-open https://google.com")
    elif "search for" in lower:
        match = re.search(r"search for (.+)", lower)
        if match: ex.search_web(match.group(1))
    elif "screenshot" in lower:
        ex.take_screenshot()
    return response

def chat_loop():
    print("\n" + "="*60)
    print("  🤖 JARVIS — Your Personal AI  |  बोलिए, Sir...")
    print("="*60)
    print("Type your command | Say 'voice' to switch to mic | 'quit' to exit\n")

    use_voice = False
    while True:
        try:
            if use_voice:
                from jarvis.core.listener import listen_once
                user_input = listen_once()
                if not user_input:
                    continue
            else:
                user_input = input("You: ").strip()

            if not user_input:
                continue
            if user_input.lower() in ("quit", "exit", "bye"):
                speak("Goodbye Sir. JARVIS shutting down.")
                break
            if user_input.lower() == "voice":
                use_voice = True
                speak("Voice mode activated. Listening, Sir.")
                continue
            if user_input.lower() == "text":
                use_voice = False
                print("Switched to text mode.")
                continue

            print("\n🧠 Thinking...")
            response = ask(user_input)
            response = extract_and_execute(response)
            print(f"\nJARVIS: {response}\n")
            speak(response)

        except KeyboardInterrupt:
            print("\nJARVIS: Shutting down. Goodbye, Sir.")
            break

if __name__ == "__main__":
    init_db()
    remember("assistant_name", "JARVIS")
    remember("user_languages", ["Hindi", "English"])
    start_tracking()
    chat_loop()
