import sqlite3, json
from datetime import datetime

DB_PATH = "./jarvis/memory/jarvis.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS user_profile (
        key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT, content TEXT, timestamp TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT, data TEXT, timestamp TEXT)""")
    conn.commit(); conn.close()

def remember(key, value):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT OR REPLACE INTO user_profile VALUES (?,?,?)",
                 (key, json.dumps(value), datetime.now().isoformat()))
    conn.commit(); conn.close()

def recall(key):
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute("SELECT value FROM user_profile WHERE key=?", (key,)).fetchone()
    conn.close()
    return json.loads(row[0]) if row else None

def get_all_profile():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("SELECT key, value FROM user_profile").fetchall()
    conn.close()
    return {r[0]: json.loads(r[1]) for r in rows}

def log_conversation(role, content):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO conversations (role,content,timestamp) VALUES (?,?,?)",
                 (role, content, datetime.now().isoformat()))
    conn.commit(); conn.close()

def get_recent_conversation(n=10):
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("SELECT role,content FROM conversations ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    conn.close()
    return list(reversed(rows))

def log_activity(event_type, data):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO activity_log (event_type,data,timestamp) VALUES (?,?,?)",
                 (event_type, json.dumps(data), datetime.now().isoformat()))
    conn.commit(); conn.close()
