import psutil, time, threading
from datetime import datetime
from jarvis.memory.db import log_activity, remember

_tracking = False

def get_active_window():
    try:
        import pygetwindow as gw
        wins = gw.getActiveWindow()
        return wins.title if wins else "Unknown"
    except:
        return "Unknown"

def get_system_stats():
    return {
        "cpu": psutil.cpu_percent(interval=0.1),
        "ram": psutil.virtual_memory().percent,
        "disk": psutil.disk_usage("/").percent,
        "battery": psutil.sensors_battery().percent if psutil.sensors_battery() else "N/A"
    }

def get_running_apps():
    apps = set()
    for proc in psutil.process_iter(["name"]):
        try: apps.add(proc.info["name"])
        except: pass
    return list(apps)[:20]

def _track_loop(interval=30):
    global _tracking
    while _tracking:
        window = get_active_window()
        stats = get_system_stats()
        log_activity("window_focus", {"window": window, "stats": stats})
        remember("last_active_window", window)
        remember("system_stats", stats)
        time.sleep(interval)

def start_tracking():
    global _tracking
    _tracking = True
    t = threading.Thread(target=_track_loop, daemon=True)
    t.start()
    print("📊 Activity tracking started")

def stop_tracking():
    global _tracking
    _tracking = False
