import mss, base64, io
from PIL import Image

def capture_screen(monitor=1) -> Image.Image:
    with mss.mss() as sct:
        screenshot = sct.grab(sct.monitors[monitor])
        img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")
    return img

def screen_to_base64(quality=85) -> str:
    img = capture_screen()
    img = img.resize((1280, 720), Image.LANCZOS)
    buffer = io.BytesIO()
    img.save(buffer, format="JPEG", quality=quality)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")

def describe_screen_with_ollama(extra_prompt="What is happening on screen?") -> str:
    import ollama
    b64 = screen_to_base64()
    response = ollama.chat(
        model="llava",  # needs llava pulled: ollama pull llava
        messages=[{
            "role": "user",
            "content": extra_prompt,
            "images": [b64]
        }]
    )
    return response["message"]["content"]
