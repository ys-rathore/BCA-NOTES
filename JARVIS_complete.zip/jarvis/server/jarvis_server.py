#!/usr/bin/env python3
"""
JARVIS FastAPI Server — Runs on your AWS Debian Server
Endpoints:
  POST /chat       — Text chat with JARVIS brain
  POST /vision     — Send screenshot, JARVIS analyzes it
  POST /speak      — Text → Hindi/English MP3 (gTTS)
  POST /execute    — Run shell command on server
  GET  /status     — Server health + loaded models
"""

import os, subprocess, base64, tempfile
from fastapi import FastAPI, Header, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional
import requests
from gtts import gTTS
from langdetect import detect

app = FastAPI(title="JARVIS Server", version="2.0")

API_KEY = os.environ.get("JARVIS_API_KEY", "jarvis-secret-2025")  # Change this!
OLLAMA_BASE = "http://localhost:11434"
BRAIN_MODEL = "llama3.2"
VISION_MODEL = "llava"
CONVERSATION_HISTORY = []


def auth(key: str):
    if key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")


class ChatRequest(BaseModel):
    message: str
    api_key: str
    model: Optional[str] = None
    include_history: bool = True


class ExecuteRequest(BaseModel):
    command: str
    api_key: str


class SpeakRequest(BaseModel):
    text: str
    api_key: str
    lang: Optional[str] = None  # auto-detect if None


@app.get("/status")
def status():
    try:
        models = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=3).json()
        model_names = [m["name"] for m in models.get("models", [])]
    except Exception:
        model_names = ["ollama not running"]
    return {"status": "online", "models": model_names, "history_length": len(CONVERSATION_HISTORY)}


@app.post("/chat")
def chat(req: ChatRequest):
    auth(req.api_key)
    CONVERSATION_HISTORY.append({"role": "user", "content": req.message})
    history = CONVERSATION_HISTORY[-20:] if req.include_history else [{"role": "user", "content": req.message}]
    system_msg = {
        "role": "system",
        "content": (
            "You are JARVIS, an extremely intelligent personal AI assistant. "
            "You understand both Hindi and English. Respond in the same language the user uses. "
            "You can perform complex tasks, analyze screens, control PC, write code, and more. "
            "Be concise, sharp, and helpful like Iron Man's JARVIS."
        )
    }
    payload = {
        "model": req.model or BRAIN_MODEL,
        "messages": [system_msg] + history,
        "stream": False
    }
    resp = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=120)
    reply = resp.json()["message"]["content"]
    CONVERSATION_HISTORY.append({"role": "assistant", "content": reply})
    return {"reply": reply, "model": req.model or BRAIN_MODEL}


@app.post("/vision")
async def vision(api_key: str = "", file: UploadFile = File(...)):
    auth(api_key)
    img_bytes = await file.read()
    b64 = base64.b64encode(img_bytes).decode()
    payload = {
        "model": VISION_MODEL,
        "messages": [{"role": "user", "content": "Describe exactly what you see on this screen. Be detailed and specific.", "images": [b64]}],
        "stream": False
    }
    resp = requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, timeout=120)
    description = resp.json()["message"]["content"]
    return {"description": description}


@app.post("/speak")
def speak(req: SpeakRequest):
    auth(req.api_key)
    lang = req.lang
    if not lang:
        try:
            detected = detect(req.text)
            lang = "hi" if detected in ["hi", "mr", "ne"] else "en"
        except Exception:
            lang = "en"
    tts = gTTS(text=req.text, lang=lang, slow=False)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3", dir="/tmp")
    tts.save(tmp.name)
    return FileResponse(tmp.name, media_type="audio/mpeg", filename="jarvis_speak.mp3")


@app.post("/execute")
def execute(req: ExecuteRequest):
    auth(req.api_key)
    try:
        result = subprocess.run(req.command, shell=True, capture_output=True, text=True, timeout=30)
        return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "Command timed out", "returncode": -1}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("jarvis_server:app", host="0.0.0.0", port=8000, reload=False)
