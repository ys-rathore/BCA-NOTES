#!/bin/bash
set -e
echo "=== JARVIS Server Setup for Debian AWS ==="

# Update system
apt-get update -y && apt-get upgrade -y
apt-get install -y python3 python3-pip python3-venv curl git screen htop

# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh
systemctl enable ollama
systemctl start ollama
sleep 3

# Pull models
echo "Pulling llama3.2 (brain)..."
ollama pull llama3.2
echo "Pulling llava (screen vision)..."
ollama pull llava

# Create Python venv
python3 -m venv /opt/jarvis-env
source /opt/jarvis-env/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn python-multipart gtts langdetect     requests pillow chromadb sentence-transformers     SpeechRecognition pydantic

echo "=== Setup Complete ==="
