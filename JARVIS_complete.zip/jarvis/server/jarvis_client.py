"""
JARVIS PC Client — Runs on your LOCAL PC
Connects to your AWS Debian server for all AI computation.
Your PC only handles: microphone input + audio playback.
"""

import requests, os, tempfile, threading
import speech_recognition as sr
from langdetect import detect

# ── CONFIG — change SERVER_URL to your AWS server IP ──────────────────────
SERVER_URL = "http://YOUR_AWS_SERVER_IP:8000"   # ← put your server IP here
API_KEY    = "jarvis-secret-2025"               # ← same as server
WAKE_WORD  = "jarvis"

# ── TTS: play MP3 from server ─────────────────────────────────────────────
def speak(text: str):
    try:
        resp = requests.post(f"{SERVER_URL}/speak",
                             json={"text": text, "api_key": API_KEY}, timeout=30)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            f.write(resp.content)
            tmp = f.name
        # Auto play based on OS
        if os.name == "nt":       # Windows
            os.system(f"start {tmp}")
        elif "darwin" in os.sys.platform:  # Mac
            os.system(f"afplay {tmp}")
        else:                     # Linux
            os.system(f"mpg123 {tmp} 2>/dev/null || vlc {tmp} 2>/dev/null")
    except Exception as e:
        print(f"[Speaker Error] {e}")


# ── Send screenshot to server ─────────────────────────────────────────────
def analyze_screen():
    try:
        import mss, io
        from PIL import Image
        with mss.mss() as sct:
            img = sct.grab(sct.monitors[0])
            pil_img = Image.frombytes("RGB", img.size, img.bgra, "raw", "BGRX")
            buf = io.BytesIO()
            pil_img.save(buf, format="PNG")
            buf.seek(0)
        resp = requests.post(f"{SERVER_URL}/vision",
                             data={"api_key": API_KEY},
                             files={"file": ("screen.png", buf, "image/png")}, timeout=60)
        return resp.json().get("description", "")
    except Exception as e:
        return f"Screen capture error: {e}"


# ── Chat with server brain ─────────────────────────────────────────────────
def chat(message: str) -> str:
    try:
        resp = requests.post(f"{SERVER_URL}/chat",
                             json={"message": message, "api_key": API_KEY}, timeout=120)
        return resp.json().get("reply", "")
    except Exception as e:
        return f"Server error: {e}"


# ── Voice listener ─────────────────────────────────────────────────────────
def listen_once() -> str:
    recognizer = sr.Recognizer()
    recognizer.energy_threshold = 300
    recognizer.dynamic_energy_threshold = True
    with sr.Microphone() as source:
        print("🎙️  Listening...")
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        audio = recognizer.listen(source, timeout=8, phrase_time_limit=15)
    try:
        text = recognizer.recognize_google(audio, language="hi-IN")
        print(f"[You] {text}")
        return text
    except sr.UnknownValueError:
        return ""
    except Exception as e:
        print(f"Mic error: {e}")
        return ""


# ── Main JARVIS loop ───────────────────────────────────────────────────────
def run():
    print("="*55)
    print("    🤖  JARVIS — Connected to AWS Server")
    print(f"    Server: {SERVER_URL}")
    print("="*55)
    # Check server
    try:
        status = requests.get(f"{SERVER_URL}/status", timeout=5).json()
        print(f"✅ Server ONLINE | Models: {status['models']}")
    except Exception:
        print("❌ Server not reachable — check your AWS IP and security group port 8000")
        return

    speak("नमस्ते Sir, मैं JARVIS हूँ — आपका AI assistant। आप बोल सकते हैं या type कर सकते हैं।")

    mode = input("\nMode? [voice/text]: ").strip().lower()

    while True:
        if mode == "voice":
            user_input = listen_once()
            if not user_input:
                continue
        else:
            user_input = input("\nYou: ").strip()
            if not user_input:
                continue

        if user_input.lower() in ["exit", "quit", "bye", "band karo"]:
            speak("Goodbye Sir.")
            break

        if "screen" in user_input.lower() or "dekho" in user_input.lower():
            print("🖥️  Analyzing screen...")
            screen_desc = analyze_screen()
            full_prompt = f"User asked: {user_input}\n\nWhat I see on screen: {screen_desc}\n\nPlease help."
            reply = chat(full_prompt)
        else:
            reply = chat(user_input)

        print(f"\nJARVIS: {reply}\n")
        speak(reply)


if __name__ == "__main__":
    run()
